package alsender.earthworks.main.proxy;

/**
 * Created by alsender on 12/17/16.
 */
public class ServerProxy extends CommonProxy {
}
